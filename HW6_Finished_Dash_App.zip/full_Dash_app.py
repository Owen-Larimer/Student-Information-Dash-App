import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import plotly.express as px
import plotly.graph_objects as go
import dash
from dash import Dash, html, dash_table, dcc
from dash.dependencies import Input, Output
import dash_bootstrap_components as dbc


students = pd.read_csv("./student-por.csv")
agg = students.groupby(['Dalc','sex'], as_index=False)['absences'].mean()
agg['absences'] = agg['absences'].round(2)


grade_cols = students.columns[-3:] #For each different grade

#For heatmap:
grouped_absences = students.groupby(['Mjob', 'Fjob'], as_index=False)[['G1', 'G2', 'G3']].mean() 

#Now for Barplot:
grouped = students.groupby(['Dalc', 'Walc', 'sex'], as_index=False)['absences'].mean()



app = Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = html.Div(
    id='theme_wrapper',
    className='light-theme',
    children =[
        dbc.Container([
         dbc.Row([
             dbc.Col(
                 html.H1("Student Information Dashboard", className='main-title'),
                 width=9
             ),
             dbc.Col([
                 dbc.Switch(
                     id='theme_toggle',
                     label='Dark Mode',
                     value=False,
                     className='mt-1'
                 )
             ], width=3)
         ], align='center', className='mb-4'),
    
        dbc.Row([
             dbc.Col([
                 html.Div(dcc.Graph(id='scatterplot'), className='graph-container graph-spacing')
             ], width = 9),
    
             dbc.Col([
                 dcc.Dropdown(
                     id ='Grade Period Select', 
                     options=grade_cols,
                     value = 'G1',
                     clearable =False,
                     className='Select-control Select-menu'
                 )
             ], width = 3),
            html.Div(className="divider")
         ], align='center'),
    
        dbc.Row([
             dbc.Col([
                 html.Div(dcc.Graph(id='heatmap'), className='graph-container graph-spacing')
             ], width = 9),
    
             dbc.Col([
                 dcc.Dropdown(
                     id ='Grade Heatmap Select', 
                     options=grade_cols,
                     value = 'G1',
                     clearable = False,
                     className='Select-control Select-menu'
                 ),
                 dbc.Switch(
                    id='heatmap_color_flip',
                    label='Invert Colors',
                    value=False,
                    className='mt-2'
                )
                 
             ], width = 3),
            html.Div(className="divider")
         ], align='center'),
    
        dbc.Row([
             dbc.Col([
                 html.Div(dcc.Graph(id='barplot'), className='graph-container graph-spacing')
             ], width = 9),
    
             dbc.Col([
                 dbc.Switch(
                     id ='Bar Mode', 
                     label = 'Grouped or Stacked',
                     value = True,
                     className ='mt-2'
                 )
             ], width = 3)
         ], align='center')
    
        
    ])
    ]
)



@app.callback(
    [Output('scatterplot', 'figure'), 
    Output('heatmap', 'figure'),
    Output('barplot', 'figure'),
    Output('theme_wrapper', 'className')],
    Input('Grade Period Select', 'value'),
    Input('Grade Heatmap Select', 'value'),
    Input('Bar Mode', 'value'),
    Input('heatmap_color_flip', 'value'),
    Input('theme_toggle', 'value')
)

                           
def update_plot(grade, grade_avg_for_heatmap, bar_mode, flip_colors, dark_mode):
    
    fig = px.scatter(students, x='absences', y=grade, color='sex', color_discrete_map={
        'F': 'hotpink',
        'M': 'dodgerblue'})

    fig.update_layout(
        title='<u>Number of Absences Association with Period Grade<u>',
        xaxis_title='Absences'
    )

    colorscale = 'RdBu_r' if flip_colors else 'RdBu'

    new_heatmap = px.density_heatmap(grouped_absences, x='Mjob', y='Fjob', z=grade_avg_for_heatmap, histfunc='avg', color_continuous_scale=colorscale)
    
    new_heatmap.update_layout(
        title="<u>Average Grade by Mother's Job and Father's Job<u>",
        xaxis_title="Mother's Job",
        yaxis_title="Father's Job",
        coloraxis_colorbar=dict(
            title="Average Grade",
            ticks="outside"
        )
    )
    
    barmode_value = 'group' if bar_mode else 'stack'

    fig4 = px.bar(
        agg, x='Dalc', y='absences', color='sex', color_discrete_map={
        'F': 'hotpink',
        'M': 'dodgerblue'}, barmode=barmode_value, labels={'Dalc':'Weekday Alcohol Consumption (1=low, 5=high)', 'absences':'Average Absences'}, text='absences'   # optional: show numbers on bars
    )

    fig4.update_layout(
        title="<u>Average Absences by Weekday Alcohol Consumption and Sex<u>",
        xaxis=dict(type='category')  # ensure Dalc treated as categorical
    )

    template = "plotly_dark" if dark_mode else "plotly_white"
    theme_class = "dark-theme" if dark_mode else "light-theme"

    fig.update_layout(template=template)
    new_heatmap.update_layout(template=template)
    fig4.update_layout(template=template)

    fig.update_layout(legend_title_text="Sex")
    fig4.update_layout(legend_title_text="Sex")
    
    return fig, new_heatmap, fig4, theme_class


# Run the app
if __name__ == '__main__':
    app.run(debug=True)